import React,{useEffect,useState} from 'react'




export default function Menu() {

useEffect(()=>{
    
})

  return (
    <div>M</div>
  )
}


