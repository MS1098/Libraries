// import React from "react";
// import "./base.css";

// import img15 from "./img/15.jpg";
// import img16 from "./img/16.jpg";
// import img17 from "./img/17.jpg";

// function Product3(){
    

//     return(
//         <div className="stack-wrap" aria-hidden="true" >
//            <div className="stack" id="stack-3">
//                         <img className="stack__img" src={img15} alt="Some image" />
//                         <img className="stack__img" src={img16} alt="Some image" />
//                         <img className="stack__img" src={img17} alt="Some image" />
//                         <img className="stack__img" src={img17} alt="Some image" />
//                         <img className="stack__img" src={img17} alt="Some image" />
//                         <img className="stack__img" src={img17} alt="Some image" />
//                         <img className="stack__img" src={img17} alt="Some image" />
//                     </div>

//         </div>
//     )
// }

// export default Product3;