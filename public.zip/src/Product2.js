// import React from "react";
// import "./base.css";
// import img8 from "./img/8.jpg";
// import img9 from "./img/9.jpg";
// import img10 from "./img/10.jpg";
// import img11 from "./img/11.jpg";
// import img12 from "./img/12.jpg";
// import img13 from "./img/13.jpg";
// import img14 from "./img/14.jpg";

// function Product2(){
    

//     return(
//         <div className="stack-wrap" aria-hidden="true">
//            <div className="stack" id="stack-2">
//                         <img className="stack__img" src={img8} alt="Some image" />
//                         <img className="stack__img" src={img9} alt="Some image" />
//                         <img className="stack__img" src={img10} alt="Some image" />
//                         <img className="stack__img" src={img11} alt="Some image" />
//                         <img className="stack__img" src={img12} alt="Some image" />
//                         <img className="stack__img" src={img13} alt="Some image" />
//                         <img className="stack__img" src={img14} alt="Some image" />
//                     </div>
//               </div>
//     )
// }

// export default Product2;